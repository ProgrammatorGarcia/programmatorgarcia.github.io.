import java.awt.*;
import java.awt.event.*;

public class MousePlayer extends Player{
	private GamePanel thePanel;

	public MousePlayer(Color c, String n, GamePanel gp){
		super(c,n);
		thePanel = gp;
	}

	public Point getMove(Board theBoard){
		thePanel.resetCurrent();

		// Create a secondary event loop so the EDT can still process mouse clicks
		EventQueue eq = Toolkit.getDefaultToolkit().getSystemEventQueue();
		SecondaryLoop loop = eq.createSecondaryLoop();

		// Add a temporary listener that exits the loop when the board is clicked
		MouseListener clickListener = new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				loop.exit();
			}
		};
		thePanel.addMouseListener(clickListener);
		loop.enter(); // blocks here but still dispatches events (including mouse clicks)
		thePanel.removeMouseListener(clickListener);

		int x = thePanel.getCurrentX();
		int y = thePanel.getCurrentY();
		return new Point(x, y);
	}
}