import java.awt.Color;
import java.awt.Point;
//import java.util.ArrayList; //See below for alternate solution

public class RandomPlayer extends Player{
	public RandomPlayer(Color c, String n){
		super(c,n);
	}
	
	public Point getMove(Board theBoard){
		int x = (int) (Math.random() * theBoard.getRows());
		int y = (int) (Math.random() * theBoard.getColumns());
		//Math.random gets a value between 0 and 1.
		//If 0 <= r < 1, then 0 <= r * getRows() < getRows(),
		//which is what we want.
		
		while(!theBoard.isLegal(x,y,getColor())){
			x = (int) (Math.random() * theBoard.getRows());
			y = (int) (Math.random() * theBoard.getColumns());
		}
		return new Point(x,y);
		
		/* There is a second solution:
		   It gathers all legal moves, and then selects one.
		ArrayList<Point> legalMoves = new ArrayList<Point>();
		for(int r=0; r<theBoard.getRows(); r++){
			for(int c=0; c<theBoard.getColumns(); c++){
				if(theBoard.isLegal(r,c, this.getColor())){
					legalMoves.add(new Point(r,c));
				}
                        }
                }
                return legalMoves.get((int)(legalMoves.size()*Math.random()));
                */
        }
}