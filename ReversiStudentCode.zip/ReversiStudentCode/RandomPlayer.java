import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;

/**
 * RandomPlayer - A simple AI that picks a random legal move.
 *
 * Use this as a reference when building your own Player!
 * Your class needs to:
 *   1. Extend Player
 *   2. Have a constructor that calls super(c, n)
 *   3. Override getMove(Board theBoard) and return a valid Point
 *
 * ========================== USEFUL BOARD METHODS ==========================
 *
 * theBoard.getRows()              - Returns the number of rows on the board.
 * theBoard.getColumns()           - Returns the number of columns on the board.
 * theBoard.getState(r, c)         - Returns the Color at (r, c), or null if empty.
 * theBoard.isOnBoard(r, c)        - Returns true if (r, c) is within bounds.
 * theBoard.isLegal(r, c, color)   - Returns true if placing your color at (r, c)
 *                                   is a valid Reversi move (flips at least one piece).
 * theBoard.hasMove(color)         - Returns true if the given color has any legal move.
 * theBoard.colorCount(color)      - Returns how many pieces of that color are on the board.
 * theBoard.getCopy()              - Returns a deep copy of the board. Use this to
 *                                   simulate moves without modifying the real board!
 *                                   e.g. Board sim = theBoard.getCopy();
 *                                        sim.placePiece(r, c, myColor);
 *                                   Now check sim to see what the board would look like.
 * theBoard.isDone()               - Returns true if the board is completely full.
 *
 * ========================== USEFUL PLAYER METHODS =========================
 *
 * this.getColor()                 - Returns your assigned Color (use this for
 *                                   isLegal, colorCount, etc.)
 * this.getName()                  - Returns your player's name.
 *
 * ================================= TIPS ==================================
 *
 * - Your getMove() receives the REAL board. Do NOT call placePiece() on it
 *   or you will be caught cheating and automatically lose!
 * - Use getCopy() to create simulations of future board states.
 * - To figure out your opponent's color, look for pieces that aren't yours:
 *       if (theBoard.getState(r,c) != null && !theBoard.getState(r,c).equals(getColor()))
 * - A Point is (row, col), not (x, y) in screen coordinates.
 * - The "Play N Games" button lets you test your AI against another player
 *   over multiple rounds, great for seeing how consistent your strategy is.
 *
 * =========================================================================
 */
public class RandomPlayer extends Player{
	public RandomPlayer(Color c, String n){
		super(c,n);
	}

	public Point getMove(Board theBoard){
		// Gather all legal moves into a list, then pick one at random.
		ArrayList<Point> legalMoves = new ArrayList<Point>();
		for(int r=0; r<theBoard.getRows(); r++){
			for(int c=0; c<theBoard.getColumns(); c++){
				if(theBoard.isLegal(r,c, this.getColor())){
					legalMoves.add(new Point(r,c));
				}
			}
		}

		//Maybe instead of returning a random move from this list with all possible moves, we... do some strategy with it. :D
		return legalMoves.get((int)(legalMoves.size()*Math.random()));
	}
}
